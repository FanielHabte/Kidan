package gateway.entity;

public class ResourcePermission {

}

//•	id (UUID, PK)
//•	user_id (UUID, FK → users.id)
//•	resource_type (enum: DATASET, SUBMISSION)
//•	resource_id (UUID)
//•	role (enum: OWNER, PROVIDER, VIEWER)
//•	granted_by (UUID, FK → users.id)
//•	granted_at (timestamp)
